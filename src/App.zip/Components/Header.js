import React from 'react'

export default function Header() {
    return (
        <div className="app-header">
            <h1>Covid-19 Information Portal</h1>
        </div>
    )
}

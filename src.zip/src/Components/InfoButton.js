import React from 'react'

export default function InfoButton() {
    return (
        <div className="d-flex align-items-center">
            <button type="button" className="">Show Latest Information</button>
        </div>
    )
}
